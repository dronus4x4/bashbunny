## Exfiltrate File Information

Author: @A_SarcasticGuy     
Target: Windows     
Version: Version 1.0

## Description

Exfiltrate file information if they start with a specific passphrase, and once complete the Bunny should be ejected

NOTE: The Bunny will only be ejected when it is not in use, so if the scan is still continuing it will fail to eject

## Configuration

HID STORAGE

## Requirements

p.ps1 file MUST be in /payloads folder.

## STATUS

| LED              | Status                                |
| ---------------- | ------------------------------------- |
| Purple           | Script Started                        |
| Yellow           | Ducky Script Started                  |
| Red              | Failed to find Ducky Script           |
