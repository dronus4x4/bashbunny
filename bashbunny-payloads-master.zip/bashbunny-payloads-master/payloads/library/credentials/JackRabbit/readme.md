# JackRabbit

* Author: illwill
* Version: Version 0.1
* Target: Windows

## Description

Jacks the Browsers/Windows/WiFi/SSH passwords and install config files from Windows boxes by downloading a 
Powershell script into memory then stashes them in /root/udisk/loot/JackRabbit/%ComputerName%

## Configuration

None needed. 

## STATUS

| LED                | Status                                       |
| ------------------ | -------------------------------------------- |
| Purple (blinking)  | Jackin dat loot                              |
| Green  (blinking)  | Jacked dat loot                              |
| RED BLUE(blinking) | PoPo caught yo ass                           |

## Discussion
 
