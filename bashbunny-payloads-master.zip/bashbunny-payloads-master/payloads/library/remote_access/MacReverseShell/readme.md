# Mac Reverse Shell

Author: mrt0mat0
Version: Version 1.0

## Description

Using ducky script, it opens a python reverse shell to the IP and PORT of your choosing. Also, as a nice little bonus, it runs the DYLD exploit that, if vulnerable will give you a root shell. 

## Configuration

This is configured for Macbooks as a keyboard. I am not 100% about how the VID and PID variables work, so that may just be BS at the top :) - That's what github is for. Exploit does not work on updated macs

## STATUS

| LED              | Status                                |
| ---------------- | ------------------------------------- |
| Blue             | Setup                                 |
| White            | Running the scripts                   |
| Red              | r00t exploit is running (optional     |
| Green            | Finished                              |