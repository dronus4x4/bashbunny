# RickRoll Prank
* Author: illwill
* Version: Version 0.1
* Target: Windows

## Description

Uses a HID/Ethernet Attack to run a RickRoll powershell script from Lee Holmes

## Configuration

None needed. 

## STATUS

| LED                | Status                                       |
| ------------------ | -------------------------------------------- |
| Blue (blinking)    | Running Powershell / Waiting for WebServer   |
| White (blinking)   | WebServer started starting the rickroll      |
| Green              | RickRoll Started, Safe to pull               |


## Discussion
[Hak5 Forum Thread](https://forums.hak5.org/index.php?/topic/40579-payload-rickroll-prank/ "Hak5 Forum Thread")
