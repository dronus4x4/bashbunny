                                                       
```                                                       
/|                    _..._     _..._                  
||                  .'     '. .'     '..-.          .- 
||                 .   .-.   .   .-.   .\ \        / / 
||  __             |  '   '  |  '   '  | \ \      / /  
||/'__ '.   _    _ |  |   |  |  |   |  |  \ \    / /   
|:/`  '. ' | '  / ||  |   |  |  |   |  |   \ \  / /    
||     | |.' | .' ||  |   |  |  |   |  |    \ `  /     
||\    / '/  | /  ||  |   |  |  |   |  |     \  /      
|/\'..' /|   `'.  ||  |   |  |  |   |  |     / /       
'  `'-'` '   .'|  '/  |   |  |  |   |  | |`-' /        
          `-'  `--''--'   '--'--'   '--'  '..'         
         .---.                                         
         |   |.--._________   _...._                   
     _.._|   ||__|\        |.'      '-.                
   .' .._|   |.--. \        .'```'.    '.              
   | '   |   ||  |  \      |       \     \             
 __| |__ |   ||  |   |     |        |    |             
|__   __||   ||  |   |      \      /    .              
   | |   |   ||  |   |     |\`'-.-'   .'               
   | |   |   ||__|   |     | '-....-'`                 
   | |   '---'      .'     '.                          
   | |            '-----------'                        
   |_| 
   ```
   
# Bunny-Flip - a BB script you didn't know you needed
Bunny-Flip is the future. Who needs to manually flip a monitor when you can do it virtually?

Windows 7 only. 
Bunnyscript uses a simple loop to flip screens every 0.300 seconds.

# Options
Currently the only options avalible are to set the amount of times you want the screen to flip.
Please see ####OPTIONS#### in payload.txt

1 = flips screen left, right, down and up once. 
