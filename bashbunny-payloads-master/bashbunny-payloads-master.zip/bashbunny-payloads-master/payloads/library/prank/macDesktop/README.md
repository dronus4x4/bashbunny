## macWallpaper by Jafahulo

* Author: Jafahulo
* Version: Version 1.0
* Target: OSX

## Description
Runs a script in background that will download pictures of my
little pony (or whatever else you'd like) and randomly sets that
as their desktop background every 45 minutes - 5 hours. change
number in for loop to decide how many times it will change their
background.

## Configuration

None

## Status
too fast to really be useful

## Discussion
https://forums.hak5.org/topic/41605-payload-macwallpaper/
