# Hosts DNS Spoofer

## Description

Redirects a domain to a set IP adres by changing the hosts file. The UAC bypass is done so it works on windows 10. 

## Configuration

Change the domain you want to redirect and the IP you want to direct it to. 
