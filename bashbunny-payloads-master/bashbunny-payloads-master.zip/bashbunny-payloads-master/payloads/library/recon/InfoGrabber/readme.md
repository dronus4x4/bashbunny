# InfoGrabber for the Bunnys

Author: Simen Kjeserud

Version: Version 1.0

Credit: Hak5Darren for inspiration

               ((`\
            ___ \\ '--._
         .'`   `'    o  )
        /    \   '. __.'
       _|    /_  \ \_\_
      {_\______\-'\__\_\
	  Check out my website:
	  aknemis.com

## Description

Gather a lot of information about the computer and place it in a text file in loot/info/.

Here you can se what it will look like:


	System Information for:  DESKTOP-9BVPPVN

	Manufacturer: Dell Inc.

	Model: XPS 13 9360

	Serial Number: *******

	CPU: Intel(R) Core(TM) i7-7500U CPU @ 2.70GHz

	HDD Capacity: 464.38GB

	HDD Space: 82.32 % Free (382.28GB)
	
	RAM: 15.89GB

	Operating System: Microsoft Windows 10 Home, Service Pack: 0

	User logged In: DESKTOP-9BVPPVN\aknem

	Last Reboot: 02/21/2017 19:49:30

	Computers MAC adress: ****************

	Computers IP adress: ***********

	Public IP adress: ****************

	RDP: RDP is NOT enabled


	| ProfileName      | SSID                                  | Password                              |
	| ---------------- | ------------------------------------- | ------------------------------------- |
	| privatsna11234   | privatsna11234                        | ********                              |
	| privatsna11234   | privatsna11234                        | ********                              |



## Configuration

Made for windows. The only thing you will need to change is the Ducky language so it matches the keyboard input.

## Requirements

DuckyTools for the BashBunny, and you need to change to the language the computer uses.

## STATUS

| LED              | Status                                |
| ---------------- | ------------------------------------- |
| Purple (blinking)| Attack in progress                    |
| Green            | Attack Finished                       |



## Discussion (Not yet created)
[Hak5 Forum Thread not yet created](https://forums.hak5.org/index.php?/topic/ "Hak5 Forum Thread") 
