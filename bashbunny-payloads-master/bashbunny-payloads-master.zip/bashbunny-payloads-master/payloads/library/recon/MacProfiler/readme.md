# MacProfiler
* Author: jdetmold
* Version: Version 1.0
* Target: Mac

## Description

Uses a HID/Storage Attack to create a system profile including the following information:
Terminal history.
Current clipboard contents.
List of users on the system.
ifconfig data.
Systems WAN IP.
All login items set to start up with the system.
List of installed Applications from /Applications.

## Configuration

None needed. 

## STATUS

| LED                | Status                                       |
| ------------------ | -------------------------------------------- |
| Blue               | Running                                      |
| Green              | Finished                                     |


## Discussion
[Hak5 Forum Thread](https://forums.hak5.org/index.php?/topic/40829-payload-macprofiler/ "Hak5 Forum Thread")
