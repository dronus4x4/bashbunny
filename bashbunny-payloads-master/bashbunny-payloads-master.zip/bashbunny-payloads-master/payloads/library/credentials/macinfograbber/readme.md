# Mac Info Grabber for the BashBunny

* Author: kmakblob
* Version: Version 1.2
* Target: OSX

## Description

A payload that grabs the chrome cookies sqlite3 file and also any spreadsheets in
the Documents folder and places them inside a folder on the BashBunny called MacLoot.

This payload can be easily modified to grab other files like word docs or csv files.

## STATUS

| LED                | Status                                       |
| ------------------ | -------------------------------------------- |
| Amber              | Executin Payload                             |
| Green              | Attack Finished                              |
| Purple             | Successfully grabbed xls or xlsx files       |
| Red                | Did not get any xls or xlsx files            |
