# WiPassDump for Bash Bunnys

* Author: Jafahulo --creds: samdeg555, hak5darren
* Version: Version 2.0
* Target: Windows

## Description

Dumps saved Wi-Fi infos including clear text passwords to the bash bunny
Saves to the loot folder on the Bash Bunny USB Mass Storage partition in WiPassDump folder.

## Configuration

None needed. 

## STATUS

| LED                | Status                                       |
| ------------------ | -------------------------------------------- |
| Red (blinking)     | Running                                      |
| Green              | Attack Complete                              |

## Discussion
None yet. 
