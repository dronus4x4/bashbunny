# Payload Library for the Bash Bunny by Hak5

![Bash Bunny](https://cdn.shopify.com/s/files/1/0068/2142/products/bashbunny_2a_large.png "Bash Bunny")

* [Purchase at HakShop.com](https://hakshop.com/products/bash-bunny "Purchase at HakShop.com")
* [Documentation and Wiki](http://wiki.bashbunny.com/#!index.md "Documentation and Wiki")
* [Bash Bunny Forums](https://forums.hak5.org/index.php?/forum/92-bash-bunny/ "Bash Bunny Forums")
* IRC: irc.hak5.org #BashBunny
